==================================================================
DBMR_Coherence
(C) 2023 Robert Malte Polzin
==================================================================

If you have any comments or suggestions then, please, send us an email at
robert.polzin@fu-berlin.de

1. Introduction
================

Download DBMR_Coherence.zip and create a directory and unzip the downloaded files into this directory.

There are two folders in DBMR_Coherence: Coherence and DBMR

In the folder Coherence are the m-files to reproduce the images and results of the paper R. Polzin, 
%% I. Klebanov, N. Nüsken and P. Koltai "Nonnegative matrix factorization for coherent set identification by direct low rank maximum likelihood estimation".

The folder DBMR uses the BMR-Toolbox of the Matlab-based software package described in the following paper: S. Gerber and I. Horenko, "Towards a direct and scalable identification of reduced models for categorical processes", PNAS, 2017.

2. How to run DBMR for Coherence?
==================

Fig. 1 (Example for strongly perturbed case, best of 100 runs)

1) Go to DBMR_Coherence\Coherence\Polzin_Code 
2) Run "Transition_Matrix_Example21.m" - This m-file generates the transition matrix of Example 21 (three coherent sets) for the strongly perturbed case (eps=10)
3) Go to DBMR_Coherence\DBMR\Gerber_Horenko_Code
4) Run “Coherence_ALA_Data_Analyze.m” - This m-file runs DBMR for the latent states k=1,...,5.
5) Run “Projection.m” - This m-file calculates the projections \Pi and \tilde{\Pi}.

In DBMR_Algorithm.m in line 131 you set the number of runs (100 runs in this example).

3. How can you reproduce the images from the paper?
==================

An example is generated for each figure of the paper.

1) Go to folder DBMR_Coherence\Coherence\Polzin_Code

2) Run ”Plot_Fig1.m” - This file plots a Lambda tilde for the strongly perturbed case (eps=10) in Fig. 1

3) Run ”Plot_Fig2.m” - This file plots a Lambda tilde for the strongly perturbed case (eps=4) in Fig. 2

4) Run ”Singular_Values_Fig3.m” - This file plots the singular values of Lambda tilde in Fig. 3

5) Run ”Histograms_Fig3.m” - This file plots the histograms in Fig. 3

6) Run ”Singular_Values_Fig4.m” - This file plots the singular values of Lambda tilde in Fig. 4

7) Run ”Histograms_Fig4.m” - This file plots the histograms in Fig. 4

8) Go to DBMR_Coherence\Coherence\Polzin_Code and Run "Transition_Matrix_Example21.m". Then run "Collective_Analysis.m" for the DBMR trajectories in Fig. 5

4. Availability
================
https://github.com/RobertMaltePolzin/DBMR_Coherence

Requirements:  MATLAB R2023a,  
MATLAB Optimisation Toolbox Library. 


