==================================================================
DBMR_Coherence
(C) 2024 Robert Malte Polzin
==================================================================

The code was implemented using MATLAB R2023b.

Requirement: MATLAB Optimisation Toolbox Library

1. Introduction
================

Download DBMR_Coherence.zip and create a directory and unzip the downloaded files into this directory.

There are three folders in DBMR_Coherence: Coherence, DBMR and GAIO.

In the folder Coherence are the m-files to reproduce the images and results of the paper R. Polzin, 
%% I. Klebanov, N. Nüsken and P. Koltai "Coherent set identification via direct low rank maximum likelihood estimation"
".

The folder DBMR uses the BMR-Toolbox of the Matlab-based software package described in the following paper: S. Gerber and I. Horenko, "Towards a direct and scalable identification of reduced models for categorical processes", PNAS, 2017. Link: https://github.com/SusanneGerber/Bayesian-Model-Reduction-Toolkit

The folder GAIO uses the Matlab-based software package described in: M. Dellnitz, G. Froyland, and O. Junge. "The algorithms behind GAIO—Set oriented numerical methods for dynamical systems." In Ergodic theory, analysis, and efficient simulation of dynamical systems, pages 145–174. Springer, 2001. Link: https://github.com/gaioguy/GAIO

2. How to run DBMR for coherence?
==================

This is Example 21 (three coherent sets) for the strongly perturbed case (best of 100 runs). 

1) Go to DBMR_Coherence\Coherence\Polzin_Code 

2) Run "Run_Coherence_DBMR.m" - This m-file runs DBMR for the Example 21 (three coherent sets) for the strongly perturbed case (eps=10) and computes the DBMR projection and the KL bound of the paper

In DBMR_Algorithm.m (in folder D:\MATLAB\DBMR_Coherence\DBMR\Gerber_Horenko_Code) in line 131 you set the number of runs (100 runs in this example).

3. How can you reproduce the images of Examples 20 and 21 from the paper?
==================

1) Go to folder DBMR_Coherence\Coherence\Polzin_Code

2) Run ”MAIN_Coherence_DBMR.m” - The m-file reproduces the images Figs. 1-2 of the paper

As examples of Fig. 1 and 2, three figures for the strongly perturbed case are plotted respectively.

3) Run "DBMR_trajectories.m" to plot the DBMR trajectory data points in Fig. 7 of the paper

4. How can you run the doube gyre with DBMR and plot Figs. 3 and 4?
==================

1) Go to folder DBMR_Coherence\Coherence\Polzin_Code\double_gyre\mfiles_double_gyre

2) Run double_gyre.m (possibly with run-double_gyre.m)

3) Go to folder Polzin_Code and run DBMR in Coherence_ALA_Data_Analyze. Results are in 'DBMR_results.mat' in the Folder D:\MATLAB\DBMR_Coherence\DBMR_Coherence\Coherence\mat_files

4) For plotting Fig. 3 and Fig. 4 of the paper, go to the folder DBMR_Coherence\Coherence\Polzin_Code\double_gyre\plots_double_gyre and run Plot_Fig3.m, Plot_Fig4_DBMR.m and Plot_Fig4_SVD.

5. Availability
================

GAIO: https://github.com/gaioguy/GAIO

DBMR: https://github.com/SusanneGerber/Bayesian-Model-Reduction-Toolkit

DBMR vs. Coherence: https://github.com/RobertMaltePolzin/DBMR_Coherence

6. Contact
================

If you have any comments or suggestions then, please, send us an email to
robert.polzin@fu-berlin.de or Peter.Koltai@uni-bayreuth.de
 


