%% function for implementing the tripling cocycle
function xNew = vec_cc(x,eps)

% parameters
a=3;
n=length(x);
xNew=zeros(n,1);

for i=1:n
            %%%%%%%%%%%%%%%%%%%%% first coherent set %%%%%%%%%%%%%%%%%%%%%%
    if x(i)<1/9
        xNew(i,1)=mod(a*x(i),1/3)+1/3;

    else if x(i)>=1/9 & x(i)<2/9
            xNew(i,1)=mod(-a*(x(i)-1/3),1/3)+1/3;

    else if x(i)>=2/9 & x(i)<3/9
            xNew(i,1)=mod(a*x(i),1/3)+1/3;
            %%%%%%%%%%%%%%%%%%%%% second coherent set %%%%%%%%%%%%%%%%%%%%%
    else if x(i)>=3/9 & x(i)<4/9
            xNew(i,1)=mod(a*x(i),1/3)+2/3;
    else if x(i)>=4/9 & x(i)<5/9
            xNew(i,1)=mod(-a*(x(i)-1/3),1/3)+2/3;

    else if x(i)>=5/9 & x(i)<6/9
            xNew(i,1)=mod(a*x(i),1/3)+2/3;

            %%%%%%%%%%%%%%%%%%%%% third coherent set %%%%%%%%%%%%%%%%%%%%%%

    else if x(i)>=6/9 & x(i)<7/9
            xNew(i,1)=mod(a*x(i),1/3);
    else if x(i)>=7/9 & x(i)<8/9
            xNew(i,1)=mod(-a*(x(i)-1/3),1/3);

    else if x(i)>=8/9 & x(i)<9/9
            xNew(i,1)=mod(a*x(i),1/3);

    end
    end
    end
    end
    end
    end
    end
    end
    end
end