%% File fo compute the objective function for measuring partition

K=3;
gamma=zeros(K,length(N_cd)); % affiliation

% lumped affiliation
%gamma=coherently_lumped_matrix(3,100);
gamma(1,1:1:25)=1;
gamma(3,26:1:50)=1;
gamma(2,51:1:100)=1;

% N_cluster=3;
% IDX = kmeans((D_V(:,2:N_cluster)),N_cluster);
% gamma(1,find(IDX==1))=1;
% gamma(2,find(IDX==2))=1;
% gamma(3,find(IDX==3))=1;
% figure; imagesc(gamma)

% DBMR
%gamma=Out(3).gamma;
figure; imagesc(gamma)


Ncd_gamma=N_cd*gamma';
lambda=zeros(length(N_cd),K);

for state_j=1:K
    N_j=sum(Ncd_gamma(:,state_j));
    for state_i=1:N_alphaY
        lambda(state_i,state_j)=Ncd_gamma(state_i,state_j)./N_j;
    end
end

size(lambda);
LogL=0;

for k=1:K
    for t=1:length(N_cd)
        for state_i=1:length(N_cd)
            if lambda(state_i,k)>1e-13
                LogL=LogL+log(lambda(state_i,k))*N_cd(state_i,t)*gamma(k,t);
            else
                LogL=LogL+log(1e-13)*N_cd(state_i,t)*gamma(k,t);
            end
        end
    end
end

LogL
Out(3).LogL

figure; imagesc(lambda*gamma)
matrix=diag(q)^-0.5*lambda*gamma*diag(p)^0.5;
[matrix_U matrix_S matrix_V]=svd(matrix);

size(lambda*gamma)
