%% File to calculate likelihood for given eps

K=2; % number of latent states
LogL_cd=zeros(K,N_alphaX);
eps=1e-13; %given eps

for k=1:K
    for t=1:N_alphaX
        for state_i=1:N_alphaY
            if P(state_i,k)>eps
                LogL_cd(k,t)=LogL_cd(k,t)-log(P(state_i,k)).*N_cd(state_i,t);
            else
                LogL_cd(k,t)=LogL_cd(k,t)-log(1e-13).*N_cd(state_i,t);
            end
        end
    end
end

size(LogL_cd)