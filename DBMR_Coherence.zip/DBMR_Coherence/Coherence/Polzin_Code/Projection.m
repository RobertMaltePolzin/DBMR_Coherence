
%% DBMR as a projection from the paper R. Polzin, 
%% I. Klebanov, N. Nüsken and P. Koltai "Coherent set identification via direct low rank maximum likelihood estimation"

%% % test6 is projection Pi, A is projection Pi tilde (from the paper)
%% ww is number of latent states
ww=1;
%k=ww+1;

%%%%%% Gamma^T times Gamma %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Pure_projection=transpose(Out(ww).gamma)*Out(ww).gamma;

%%%%%% Projection %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% test6 is projection Pi
test6=inv(diag(1./sum(N_cd)))*diag(1./sum(N_cd*Out(ww).gamma'*Out(ww).gamma))*Pure_projection;
P_new=N_cd*diag(1./sum(N_cd));
p=sum(N_cd)/sum(N_cd(:)); % vector p

% A is projection Pi tilde 
A=diag(p)^-0.5*test6*diag(p)^0.5; 
Capital_Lambda=P_new*test6;
q=sum(N_cd')/sum(N_cd(:)); %vector q 
Capital_Lambda_tilde=diag(q)^-0.5*P_new*test6*diag(p)^0.5;
P_til=diag(q)^-0.5*P_new*diag(p)^0.5; 

%%%%%% SVD %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[A2_U A2_S A2_V]=svd(test6); % Pi
[A_U A_S A_V]=svd(A); % Pi tilde
[D_U D_S D_V]=svd(Capital_Lambda_tilde); % Lambda tilde
[P_U P_S P_V]=svd(P_til); % P tilde
[P_new_U P_new_S P_new_V]=svd(P_new); % Ulam matrix P
P_new_projection=P_new_U(:,1:ww)*P_new_S(1:ww,1:ww)*P_new_V(:,1:ww)';
[D_U2 D_S2 D_V2]=svd(Capital_Lambda); % Ulam matrix P times projection Pi

figure; imagesc(test6); colorbar; 
title("Matrix $\Pi$ for perturbation $\epsilon=$" + dd + "",'Interpreter','latex', 'FontSize', 16)

figure; imagesc(Capital_Lambda_tilde); colorbar; 
title("Matrix $\tilde{\Lambda}$ for perturbation $\epsilon=$" + dd + "",'Interpreter','latex', 'FontSize', 16)

%%%%%%%%%%%%%%%%%%%%% Plot of spectrum %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure;
% kk=3
% plot([1:kk],diag(A_S(1:kk,1:kk),0),'s')
% legend({'$\widetilde{A}$'},'Interpreter','latex')
% hold on
% plot([1:kk],diag(D_S(1:kk,1:kk),0),'+')
% legend({'$\widetilde{L}\widetilde{A}$'},'Interpreter','latex')
% hold on
% plot([1:kk],diag(P_S(1:kk,1:kk),0),'kx')
% ylim([0 1.1])
% xlim([1 kk])
% leg1 = legend('$\widetilde{L}$');
% leg1 = legend('$\widetilde{A}$','$\widetilde{L}\widetilde{A}$','$\widetilde{L}$');
% set(leg1,'Interpreter','latex');
% set(leg1,'FontSize',10);
% 
% xlabel({'$i$'},'Interpreter','latex');
% ylabel({'$\sigma_{i}$'},'Interpreter','latex')
% legend

%%%%%%%%%%%%%%%%%%%%% Kmeans clustering %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%N_cluster = 3;   %(Anzahl Cluster)               
%IDX = kmeans((A_V(:,2:N_cluster)),N_cluster);

% figure; imagesc(A)
% figure; imagesc(Digger)
% figure; imagesc(L_til)
% figure
% scatter([1:120],D_V(:,1),30,IDX,'filled')
% title('V(:,1)');
% 
% figure
% scatter([1:120],D_V(:,2),30,IDX,'filled')
% title('2nd SV');
% grid on
% 
% figure
% scatter([1:120],D_V(:,3),30,IDX,'filled')
% title('3rd SV');
% grid on
