
%% Example in Remark 7: two linearly independent vectors

LA_S=zeros(3,100);
Log_S=zeros(3,100);

P2=[];
Gamma2=[];
testnew=[];

%% Distinction between left and right

i_1=0;
i_2=0;
i_3=0;
i_4=0;
i_5=0;

P_1=[];
Gamma_1=[];
Log_1=[];

P_2=[];
Gamma_2=[];
Log_2=[];

P_3=[];
Gamma_3=[];
Log_3=[];

P_4=[];
Gamma_4=[];
Log_4=[];

P_5=[];
Gamma_5=[];
Log_5=[];

LA_S_1=zeros(3,100);
Log_S_1=zeros(3,100);

for pp=1:100
    Coherence_ALA_Data_Analyze
    Projection
    affil=Out(1).gamma;

    %%% Loop over affiliations

    if (sum(affil(1,1:2))==2 & affil(2,3)==1)
        i_1=i_1+1;

        P_1=[P_1; Out(1).P'];
        Gamma_1=[Gamma_1; affil];
        Log_1=[Log_1; Out(1).LogL];

    else if (sum(affil(1,2:3))==2 & affil(2,1)==1)
            i_2=i_2+1;

            P_2=[P_2; Out(1).P'];
            Gamma_2=[Gamma_2; affil];
            Log_2=[Log_2; Out(1).LogL];

    else if (sum(affil(2,1:2))==2 & affil(1,3)==1)
            i_3=i_3+1;

            P_3=[P_3; Out(1).P'];
            Gamma_3=[Gamma_3; affil];
            Log_3=[Log_3; Out(1).LogL];

    else if (sum(affil(2,2:3))==2 & affil(1,1)==1)
            i_4=i_4+1;
            P_4=[P_4; Out(1).P'];
            Gamma_4=[Gamma_4; affil];
            Log_4=[Log_4; Out(1).LogL];

    else
        i_5=i_5+1;
        P_5=[P_5; Out(1).P'];
        Gamma_5=[Gamma_5; affil];
        Log_5=[Log_5; Out(1).LogL];

    end
    end

    end

    end

    LA_S(:,pp)=diag(D_S(1:3,1:3));
    Log_S(1,pp)=Out(1).LogL;

end

test=[LA_S(2,:); Log_S(1,:)];
figure; bar([i_1;i_2;i_3;i_4;i_5],0.2,'k')
figure; hist3(test')
xlabel({'$\sigma_{2}(\widetilde{L}\widetilde{A})$'},'Interpreter','latex','FontSize', 16);
ylabel('LogL')

% kmeans clustering
N_cluster = 2; IDX = kmeans((D_V(:,2:N_cluster)),N_cluster); figure; scatter(flip(J'),I',30,IDX(flip(J')),'filled')
xticks([0:10:100])
xticklabels({'0','10','20','30','40','50','60','70','80','90','100'})
yticks([0:10:100])
yticklabels({'100','90','80','70','60','50','40','30','20','10','0'})
xlabel({'$j$'},'Interpreter','latex','FontSize', 16);
ylabel({'$i$'},'Interpreter','latex','FontSize', 16);
title('(b)', 'FontSize', 15);

