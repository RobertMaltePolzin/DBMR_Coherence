
darkRed = [0.5, 0, 0];
darkGreen = [0, 0.5, 0];
darkBlue = [0, 0, 0.5];

tempk=zeros(50,1);
tempk(:)=-inf;

tempk=zeros(50,1);
tempk(:)=-inf;

for i=1:100
    Coherence_ALA_Data_Analyze 
    hold on;
    %plot([2:10],[Out(1:9).LogL],'b*')
    for j=1:4
        
        if Out(j).LogL>tempk(j)
            tempk(j)=Out(j).LogL;
            if  j==1 || j==2 || j==3 || j==4 
                %j==5 || j==6 || j==7 || j==8 || j==9 || j==10
            save(strcat('DBMR_red_2',num2str(j)))
            end
        end
        hold on;
    end
end

hold on;
plot([2:9],[tempk(1:8)],'r*');
% hold on
% plot(1,LL,'r*');
% hold on
% yline(LL,'--r',{''});
% 
xlabel('K (Number of Collective Causality Boxes)')
ylabel('Log-likelihood bound')
