%% function to calculate randomly lumped matrix
function lumped=randomly_lumped_matrix(K,n)

%K=3;
%n=100;

% Lumped matrix
lumped=zeros(K,n);

anzahl1=ceil(n*rand(1));
while anzahl1==0 || anzahl1==n
anzahl1=ceil(n*rand(1));
end 

latent1=ceil(K*rand(1));

anzahl2 = ceil((n-anzahl1)*rand(1));
while anzahl2==0;
anzahl2 = ceil((n-anzahl1)*rand(1));
end 

latent2=ceil(K*rand(1));

% while loop %
while latent2==latent1;
latent2=ceil(K*rand(1));
end 

anzahl3 = n-anzahl1-anzahl2;

latent3=ceil(K*rand(1));

% while loop %
while latent3==latent1 || latent3==latent2;
latent3=ceil(K*rand(1));
end 

lumped(latent1,1:anzahl1)=1;
lumped(latent2,(anzahl1+1):(anzahl1+anzahl2))=1;
lumped(latent3,(anzahl1+anzahl2+1):n)=1;

imagesc(lumped)
disp("randomly lumped - I like")
end