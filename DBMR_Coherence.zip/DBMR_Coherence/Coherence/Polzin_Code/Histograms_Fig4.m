%% Histograms of Fig. 4 from the paper R. Polzin, I. Klebanov, N. Nüsken 
%% and P. Koltai "Nonnegative matrix factorization for coherent set identification by direct low rank maximum likelihood estimation"

%% Example 22 (piecewise expanding interval map)
% Mat-files are in the folder DBMR_Coherence\Coherence\mat_files:
% No perturbation: 2_d0_100.mat
% Small perturbation: 2_d1_100.mat
% Large perturbation: 2_d4_100.mat

%% No perturbation: 2_d0_100.mat %%
clear all
clc

FileName   = '2_d0_100.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File); 
matrix=sum(LA_S(1:3,:));
test=[matrix; Log_S(1,:)];

figure;
plot(test(1,:),test(2,:),'k.','MarkerSize',16)
xlabel({'$\mathcal{C}_{3}(\Lambda)$'},'Interpreter','latex','FontSize', 16);
ylabel('$\hat\ell(\lambda,\Gamma)$','Interpreter','latex','FontSize', 16)
set(gca,'FontSize',20) % Size is 20
xlim([2.0 3.1]);
xticks([2.0 2.2 2.4 2.6 2.8 3.0 3.2])

%% Small perturbation: 2_d1_100.mat %%
clear all
clc
FileName   = '2_d1_100.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File); 
matrix=sum(LA_S(1:3,:));
test=[matrix; Log_S(1,:)];

figure;
hist3(test', 'edges', {2.0:0.1:3.1,-3.3*10^4:10^3/1.5:-2.7*10^4},'CDataMode','auto');
xlabel({'$\mathcal{C}_{3}(\Lambda)$'},'Interpreter','latex','FontSize', 16);
ylabel('$\hat\ell(\lambda,\Gamma)$','Interpreter','latex','FontSize', 16)
colorbar('north')
view(2)
hallo=flip(bone);
colormap(hallo);
axis tight
set(gca,'FontSize',16)
caxis([0 100]);
set(gca,'FontSize',20) % Size is 20

%% Large perturbation: 2_d4_100.mat %%
clear all
clc
FileName   = '2_d4_100.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File); 
matrix=sum(LA_S(1:3,:));
test=[matrix; Log_S(1,:)];

figure;
hist3(test', 'edges', {2.0:0.1:3.1,-3.3*10^4:10^3/1.5:-2.7*10^4},'CDataMode','auto');
xlabel({'$\mathcal{C}_{3}(\Lambda)$'},'Interpreter','latex','FontSize', 16);
ylabel('$\hat\ell(\lambda,\Gamma)$','Interpreter','latex','FontSize', 16)
colorbar('north')
view(2)
hallo=flip(bone);
colormap(hallo);
axis tight
set(gca,'FontSize',16)
caxis([0 100]);
set(gca,'FontSize',20) % Size is 20
