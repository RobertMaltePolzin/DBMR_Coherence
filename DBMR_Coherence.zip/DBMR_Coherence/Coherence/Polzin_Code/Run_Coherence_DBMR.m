
%% Run Example 21 (three coherent sets)
Transition_Matrix_Example21

%% Run DBMR
Coherence_ALA_Data_Analyze

% change directory
cd ..
cd ..
cd Coherence
cd Polzin_Code\

%% DBMR projection
Projection

%% KL bound computation 
KL_bound_DBMR_Coherence

