
%% Example 22 (piecewise expanding interval map)
% Mat-files are in the folder DBMR_Coherence\Coherence\mat_files:
% No perturbation: 2_d0.mat
% Small perturbation: 2_d1.mat
% Large perturbation: 2_d4.mat

%clear all
%clc

FileName   = '2_d0.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);

%%% P_new %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,400]); % plot width and height
axes('Units', 'normalized', 'Position',[16*delt, 18*delt, 1-20*delt, 1-20*delt]);

%%% Select the matrix to be plotted
imagesc(P_new) % matrix P

% default gamma
default_gamma=zeros(3,length(N_cd)); % default
default_gamma(1,1:1:30)=1;
default_gamma(2,31:1:60)=2;
default_gamma(3,61:1:90)=3;
default_gamma=sum(default_gamma);
default_gamma=default_gamma';

colormap(flip(gray));
caxis([0 0.1])

xticks(0:10:90)
xticklabels({'','10','20','30','40','50','60','70','80','90'})

yticks(0:10:90)
yticklabels({'','10','20','30','40','50','60','70','80','90'})

axis equal
axis tight

xlabel({'$j$'},'Interpreter','latex','FontSize', 20);
ylabel({'$i$'},'Interpreter','latex','FontSize', 20);

set(gca,'FontSize',16)

value=90.*ones(90,1);

ind1=find(default_gamma==1);
ind2=find(default_gamma==2);
ind3=find(default_gamma==3);

ones1=ones(length(ind1),1);
ones2=ones(length(ind2),1);
ones3=ones(length(ind3),1);

hold on; scatter(ind1,value(ind1),'r','filled');
hold on; scatter(ind2,value(ind2),'g','filled');
hold on; scatter(ind3,value(ind3),'y','filled');

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

%%% P_new_projection %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,400]);
axes('Units', 'normalized', 'Position',[16*delt, 18*delt, 1-20*delt, 1-20*delt]);

%%% Select the matrix to be plotted
imagesc(P_new_projection) % SVD projection

%%% Select right singular function of the matrix
N_cluster = 3; IDX = kmeans((P_V(:,2:N_cluster)),N_cluster); % P tilde

colormap(flip(gray));
caxis([0 0.1])

xticks(0:10:90)
xticklabels({'','10','20','30','40','50','60','70','80','90'})

yticks(0:10:90)
yticklabels({'','10','20','30','40','50','60','70','80','90'})

axis equal
axis tight

xlabel({'$j$'},'Interpreter','latex','FontSize', 20);
ylabel({'$i$'},'Interpreter','latex','FontSize', 20);

set(gca,'FontSize',16)

value=90.*ones(90,1);

ind1=find(IDX==1);
ind2=find(IDX==3);
ind3=find(IDX==2);

ones1=ones(length(ind1),1);
ones2=ones(length(ind2),1);
ones3=ones(length(ind3),1);

hold on; scatter(ind1,value(ind1),'r','filled');
hold on; scatter(ind2,value(ind2),'g','filled');
hold on; scatter(ind3,value(ind3),'y','filled');

%%% Plot output
N_cluster = 3; IDX2 = kmeans((P_U(:,2:N_cluster)),N_cluster);
% 
zeros1=zeros(101,1);
% 
ind1_2=find(IDX2==1);
ind2_2=find(IDX2==2);
ind3_2=find(IDX2==3);
% 
hold on; scatter(zeros1(ind1_2),ind1_2,'r','filled');
hold on; scatter(zeros1(ind2_2),ind2_2,'y','filled');
hold on; scatter(zeros1(ind3_2),ind3_2,'g','filled');

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

%%% Capital_Lambda %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,400]);
axes('Units', 'normalized', 'Position',[16*delt, 18*delt, 1-20*delt, 1-20*delt]);

%%% Select the matrix to be plotted
%imagesc(P_new) % matrix P
%imagesc(P_new_projection) % SVD projection
imagesc(Capital_Lambda) % Lambda tilde matrix

%%% Select right singular function of the matrix
%N_cluster = 3; IDX = kmeans((P_V(:,2:N_cluster)),N_cluster); % P tilde
N_cluster = 3; IDX = kmeans((D_V(:,2:N_cluster)),N_cluster); % Lambda tilde matrix

colormap(flip(gray));
caxis([0 0.1])

xticks(0:10:90)
xticklabels({'','10','20','30','40','50','60','70','80','90'})

yticks(0:10:90)
yticklabels({'','10','20','30','40','50','60','70','80','90'})

axis equal
axis tight

xlabel({'$j$'},'Interpreter','latex','FontSize', 20);
ylabel({'$i$'},'Interpreter','latex','FontSize', 20);

set(gca,'FontSize',16)

value=90.*ones(90,1);

ind1=find(IDX==1);
ind2=find(IDX==3);
ind3=find(IDX==2);

ones1=ones(length(ind1),1);
ones2=ones(length(ind2),1);
ones3=ones(length(ind3),1);

hold on; scatter(ind1,value(ind1),'y','filled');
hold on; scatter(ind3,value(ind3),15,'r','filled');
hold on; %scatter(ind2,value(ind2),'g','filled');

scatter(ind2,value(ind2),15,'g','filled');
%scatter(b(:,1),b(:,2),30,U(:,3),'filled');

D=Out(3).P;
[M,Ind] = max(D');

zeros2=zeros(100,1);

ind1=find(Ind==1);
ind2=find(Ind==2);
ind3=find(Ind==3);

hold on; scatter(zeros2(ind1),ind1,'r','filled');
hold on; scatter(zeros2(ind2),ind2,'y','filled');
hold on; scatter(zeros2(ind3),ind3,'g','filled');

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

