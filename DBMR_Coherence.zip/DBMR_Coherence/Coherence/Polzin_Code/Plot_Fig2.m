
%% Example 22 (piecewise expanding interval map)
% Mat-files are in the folder DBMR_Coherence\Coherence\mat_files:
% No perturbation: 2_d0.mat
% Small perturbation: 2_d1.mat
% Large perturbation: 2_d4.mat

%clear all
%clc

FileName   = '2_d4.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,400]);
axes('Units', 'normalized', 'Position',[16*delt, 18*delt, 1-20*delt, 1-20*delt]);

%%% Select the matrix to be plotted
%imagesc(P_new) % matrix P
%imagesc(P_new_projection) % SVD projection
imagesc(Capital_Lambda) % Lambda tilde matrix

%%% Select right singular function of the matrix
%N_cluster = 3; IDX = kmeans((P_V(:,2:N_cluster)),N_cluster); % P tilde
N_cluster = 3; IDX = kmeans((D_V(:,2:N_cluster)),N_cluster); % Lambda tilde matrix

colormap(flip(gray));
caxis([0 0.1])

xticks(0:10:90)
xticklabels({'0','10','20','30','40','50','60','70','80','90'})

yticks(0:10:90)
yticklabels({'0','10','20','30','40','50','60','70','80','90'})

axis equal
axis tight

xlabel({'$j$'},'Interpreter','latex','FontSize', 20);
ylabel({'$i$'},'Interpreter','latex','FontSize', 20);

set(gca,'FontSize',16)

value=90.*ones(90,1);

ind1=find(IDX==1);
ind2=find(IDX==3);
ind3=find(IDX==2);

ones1=ones(length(ind1),1);
ones2=ones(length(ind2),1);
ones3=ones(length(ind3),1);

hold on; scatter(ind1,value(ind1),'r','filled');
hold on; scatter(ind2,value(ind2),'g','filled');
hold on; scatter(ind3,value(ind3),'y','filled');

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

