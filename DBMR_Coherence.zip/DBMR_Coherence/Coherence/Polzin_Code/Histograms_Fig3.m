%% Histograms of Fig. 3 from the paper R. Polzin, I. Klebanov, N. Nüsken
%% and P. Koltai "Nonnegative matrix factorization for coherent set identification by direct low rank maximum likelihood estimation"

%% Example 21 (three coherent sets)
% Mat-files are in the folder DBMR_Coherence\Coherence\mat_files:
% No perturbation: 1_d0_100.mat
% Small perturbation: 1_d2_100.mat
% Large perturbation: 1_d10_100.mat

%% No perturbation: 1_d0_100.mat %%
%clear all
%clc

FileName   = '1_d0_100.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);
matrix=sum(LA_S(1:3,:));
test=[matrix; Log_S(1,:)];

figure;
hist3(test', 'edges', {1.7:0.1:2.7,-1.1*10^5:10^3*2.2:-9*10^4},'CDataMode','auto');
xticks([1.7 1.9 2.1 2.3 2.5 2.7 2.9 3.1])
xlabel({'$\mathcal{C}_{3}(\Lambda)$'},'Interpreter','latex','FontSize', 16);
ylabel('$\hat\ell(\lambda,\Gamma)$','Interpreter','latex','FontSize', 16)
colorbar('north')
view(2)
hallo=flip(bone);
colormap(hallo);
axis tight
set(gca,'FontSize',16)
caxis([0 100]);
set(gca,'FontSize',20) % Size is 20

%% Small perturbation: 1_d2_100.mat %%
%clear all
%clc

FileName   = '1_d2_100.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);
matrix=sum(LA_S(1:3,:));
test=[matrix; Log_S(1,:)];

figure;
hist3(test', 'edges', {1.7:0.1:2.7,-1.1*10^5:10^3*2.2:-9*10^4},'CDataMode','auto');
xticks([1.7 1.9 2.1 2.3 2.5 2.7 2.9 3.1])
xlabel({'$\mathcal{C}_{3}(\Lambda)$'},'Interpreter','latex','FontSize', 16);
ylabel('$\hat\ell(\lambda,\Gamma)$','Interpreter','latex','FontSize', 16)
colorbar('north')
view(2)
hallo=flip(bone);
colormap(hallo);
axis tight
set(gca,'FontSize',16)
caxis([0 100]);
set(gca,'FontSize',20) % Size is 20

%% Large perturbation: 1_d10_100.mat %%
%clear all
%clc

FileName   = '1_d10_100.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);
matrix=sum(LA_S(1:3,:));
test=[matrix; Log_S(1,:)];

figure;
plot(test(1,:),test(2,:),'k.','MarkerSize',16)
xlabel({'$\mathcal{C}_{3}(\Lambda)$'},'Interpreter','latex','FontSize', 16);
ylabel('$\hat\ell(\lambda,\Gamma)$','Interpreter','latex','FontSize', 16)
set(gca,'FontSize',20) % Size is 20
xlim([1.7 2.2]);
xticks([1.7 1.8 1.9 2.0 2.1 2.2 2.3])
