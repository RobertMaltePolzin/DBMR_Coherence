%% function to calculate coherently_lumped matrix
function lumped_matrix=coherently_lumped_matrix(K,n)

%K=3; K latent states
%n=100; n number input cats

lumped_matrix=zeros(K,n);
% 
% 
% %%%%%%%%%%%%%%%%%%%%%% lumped %%%%%%%%%%%%%%%%%%%%%%%%%%
rr=randi([1 4],1,1);
if rr==1
lumped_matrix(1,1:1:25)=1;
lumped_matrix(2,26:1:50)=1;
lumped_matrix(3,51:1:100)=1;
end

if rr==2
lumped_matrix(1,51:1:100)=1;
lumped_matrix(2,26:1:50)=1;
lumped_matrix(3,1:1:25)=1;
end

if rr==3
lumped_matrix(1,26:1:50)=1;
lumped_matrix(2,1:1:25)=1;
lumped_matrix(3,51:1:100)=1;
end

if rr==4
lumped_matrix(1,51:1:100)=1;
lumped_matrix(2,1:1:25)=1;
lumped_matrix(3,26:1:50)=1;
end


imagesc(lumped_matrix)
disp("coherently lumped - I like")

end