%% Example 23 (Periodically perturbed double gyre)
% The mat file will be saved in the folder DBMR_Coherence\DBMR_Coherence\Coherence\Polzin_Code\double_gyre\mfiles_double_gyre 

close all; clear all; clc

% run double_gyre.m
double_gyre

% save mat file
save("Double_Gyre")

