%% TPMATRIX   transition probability matrix.
function [T IJS In_Out N_cd AA BB] = tpmatrix_double_gyre(tree, f, X, depth, verbose,rho)

%   TPMATRIX(t, f, X, d, v) computes the matrix T of transition
%   probabilities between the boxes in the tree t
%
%   t       tree containing the box covering
%   f       map
%   X       m x d-matrix of sample points, m test points
%   d       depth of the tree on which the matrix is computed
%   v       verbose flag: '0' or '1' ('1' prints progress)

d = tree.dim; %2
b = tree.boxes(depth);   % get the geometry of the boxes 128x6
N = size(b,2); %6

M=N; % Fall m=n
%structure with the fields
S=whos('X');
l = floor(5e7/S.bytes);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I = []; IJS = []; tic;
%% floor rounds M/l to the nearest integer less than or equal to M/l.
for k = 0:floor(M/l);   % split in chunks of size l
    floor(M/l)
    K = k*l+1:min((k+1)*l,M);
    c = b(1:d,K);      % centers of the boxes
    r = b(d+1:2*d,1);  % radii of the boxes
    n = size(c,2);     % anzahl boxen 2^7
    E = ones(n,1);

    %H=X*diag(r);
    %new=[];
    %centers=[];
    %JJ=[];

    P = kron(E,X)*diag(r) + kron(c',ones(size(X,1),1)); % sample points in all boxes

    %%%%%%% start: add noise for points in P %%%%%%%
    AA=P; %figure; scatter(AA(:,1),AA(:,2)); title('Initial data points')
    %size(AA)

    pert = -rho + (rho+rho)*rand(length(AA),2);
    AA=AA+pert; %figure; scatter(AA(:,1),AA(:,2)); title('Initial data points with noise')
    %size(AA)

    % reflecting boundary conditions for initial data points
    AA(find(AA(:,1)>2),1)=2-(AA(find(AA(:,1)>2),1)-2);
    AA(find(AA(:,2)>1),2)=1-(AA(find(AA(:,2)>1),2)-1);
    AA(find(AA(:,1)<0),1)=-(AA(find(AA(:,1)<0),1));
    AA(find(AA(:,2)<0),2)=-(AA(find(AA(:,2)<0),2));
    %size(AA)

    %figure; scatter(AA(:,1),AA(:,2)); title('Initial data points with noise with reflecting boundary conditions')
    P=AA;
    %%%%%%% end: add noise for points in P  %%%%%%%

    %%% add noise for points in P %%%
    BB=f(P); %figure; scatter(BB(:,1),BB(:,2)); title('Evolved data points')
    %size(BB)

    pert = -rho + (rho+rho)*rand(length(BB),2);
    BB=BB+pert; %figure; scatter(AA(:,1),AA(:,2)); title('Initial data points with noise')
    %size(BB)

    % reflecting boundary conditions for evolved data points
    BB(find(BB(:,1)>2),1)=2-(BB(find(BB(:,1)>2),1)-2);
    BB(find(BB(:,2)>1),2)=1-(BB(find(BB(:,2)>1),2)-1);
    BB(find(BB(:,1)<0),1)=-(BB(find(BB(:,1)<0),1));
    BB(find(BB(:,2)<0),2)=-(BB(find(BB(:,2)<0),2));
    %size(BB)

    %figure; scatter(BB(:,1),BB(:,2)); title('Evolved data points with noise with reflecting boundary conditions')

    I = tree.search(BB', depth);   % get box numbers of image point
    %I
    J=tree.search(AA', depth);
    %J
    %I = tree.search(f(P)', depth);   % get box numbers of image point

    pI = find(I>0);  % I <= 0 iff f(P) is outside of covering
    pJ = find(J>0);

    %J = kron(K',ones(size(X,1),1));

    In_Out=[I(pI), J(pJ)];

    [I,J,S] = find(sparse(I(pI), J(pI), 1,N,M));  % transition matrix

    %size(I)
    %size(J)

    IJS = [IJS; I,J,S];
    if verbose, fprintf('%d of %d boxes, %.1f sec\n',min((k+1)*l,N),N,toc); end
end

N_cd = sparse(IJS(:,1), IJS(:,2), IJS(:,3),N,M);


QQ=N_cd;
cs = sum(N_cd);
T=N_cd*spdiags(1./cs', 0, M, M);
if verbose, fprintf('\n'); end


