%% Example 23 (Periodically perturbed double gyre)
% Mat-file is in the folder DBMR_Coherence\Coherence\mat_files:
% Mat file: DBMR_results.mat

% DBMR results are plotted for r=3 and r=5 for Gamma and Lambda

clear all
clc

FileName   = 'DBMR_results.mat';
FolderName = ['../../..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);

%%% Gamma for r=3 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

B=Out(3).gamma;

scatter(b(:,1),b(:,2),[],3*B(1,:)+2*B(2,:)+1*B(3,:),'filled');

colorbar;
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

c = colorbar;
c.Ticks = [1 2 3];

%%% Sets F_k for Lambda for r=3 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

B=Out(3).P;
[M,Ind] = max(B');

% Set coloring
coloring=zeros(1,length(Ind));
Ind1=find(Ind==1); coloring(Ind1)=3;
Ind2=find(Ind==2); coloring(Ind2)=2;
Ind3=find(Ind==3); coloring(Ind3)=1;

scatter(b(:,1),b(:,2),[],coloring,'filled');

colorbar;
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

c = colorbar;
c.Ticks = [1 2 3];

%%% Gamma for r=5 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

C=Out(5).gamma;

scatter(b(:,1),b(:,2),[],5*C(1,:)+1*C(2,:)+3*C(3,:)+4*C(4,:)+2*C(5,:),'filled');

colorbar;
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

c = colorbar;
c.Ticks = [1 2 3 4 5];

%%% Sets F_k for Lambda for r=5 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

D=Out(5).P;
[M,Ind] = max(D');

% Set coloring
coloring=zeros(1,length(Ind));
Ind1=find(Ind==1); coloring(Ind1)=5;
Ind2=find(Ind==2); coloring(Ind2)=1;
Ind3=find(Ind==3); coloring(Ind3)=3;
Ind4=find(Ind==4); coloring(Ind4)=4;
Ind5=find(Ind==5); coloring(Ind5)=2;

scatter(b(:,1),b(:,2),[],coloring,'filled');

colorbar;
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

c = colorbar;
c.Ticks = [1 2 3 4 5];
