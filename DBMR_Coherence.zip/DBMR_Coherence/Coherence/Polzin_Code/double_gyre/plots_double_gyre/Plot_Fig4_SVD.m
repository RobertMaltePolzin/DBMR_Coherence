%% Example 23 (Periodically perturbed double gyre)
% Mat-files are in the folder DBMR_Coherence\Coherence\mat_files:
% No perturbation: DBMR_results.mat

% Plot of SVD approach for the double gyre for r=3 and r=5 coherent pairs

clear all
clc

FileName   = 'DBMR_results.mat';
FolderName = ['../../..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

%%% Coherent pairs for r=3 %%%

% k-means clustering with third right singular vector %

N_cluster = 3; % number of clusters                                           
IDX=kmeans((V(:,1:N_cluster)),N_cluster);
scatter(b(:,1),b(:,2),30,IDX,'filled');
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [min(IDX) 2 max(IDX)];

% k-means clustering with third left singular vector %

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

%%% Third left singular vector %%%
N_cluster = 3; % number of clusters                                           
IDX=kmeans((U(:,1:N_cluster)),N_cluster);
scatter(b(:,1),b(:,2),30,IDX,'filled');
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [min(IDX) 2 max(IDX)];

%%% Coherent pairs for r=5 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

% k-means clustering with fifth right singular vector %

N_cluster = 5; % number of clusters                                           
IDX=kmeans((V(:,1:N_cluster)),N_cluster);
scatter(b(:,1),b(:,2),30,IDX,'filled');
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [1 2 3 4 5];

% k-means clustering with fifth left singular vector %

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,200]); % plot width and height
axes('Units', 'normalized', 'Position',[5*delt, 18*delt, 1-6*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

%%% Third left singular vector %%%
N_cluster = 5; % number of clusters                                           
IDX=kmeans((U(:,1:N_cluster)),N_cluster);
scatter(b(:,1),b(:,2),30,IDX,'filled');
axis equal
axis tight
xticks([0:0.5:2]);
ylim([0 1]);
xlim([0 2]);

format long;
c = colorbar;
c.Ticks = [1 2 3 4 5];





