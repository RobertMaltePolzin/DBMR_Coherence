%% Example 23 (Periodically perturbed double gyre)
% Contour plot of \Psi of the double gyre in Eq. (36) in the paper R. Polzin, 
% I. Klebanov, N. Nüsken and P. Koltai "Coherent set identification 
% via direct low rank maximum likelihood estimation"

clear all
clc

%%% t=1/4 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,260]); % plot width and height
axes('Units', 'normalized', 'Position',[10*delt, 18*delt, 1-12*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

A=0.25; delta=0.25; omega=2*pi; t=1/4;

x = 0:0.01:2;
y = 0:0.01:1;
[X,Y] = meshgrid(x,y);
Psi=A*sin(X.^2*pi*delta*sin(omega*t)+X.*pi*(1-2*delta*sin(omega*t))).*sin(Y.*pi);
contour(X,Y,Psi,'k','linewidth',1)

axis equal;
axis tight;

%%% t=3/4 %%%

xList = linspace(-2,2,2000)';
delt = 0.01;

myfig = figure('Position',[100,100,400,260]); % plot width and height
axes('Units', 'normalized', 'Position',[10*delt, 18*delt, 1-12*delt, 1-30*delt]);

pos = get(myfig,'Position');
set(myfig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

A=0.25; delta=0.25; omega=2*pi; t=3/4;

x = 0:0.01:2;
y = 0:0.01:1;
[X,Y] = meshgrid(x,y);
Psi=A*sin(X.^2*pi*delta*sin(omega*t)+X.*pi*(1-2*delta*sin(omega*t))).*sin(Y.*pi);
contour(X,Y,Psi,'k','linewidth',1)

axis equal;
axis tight;