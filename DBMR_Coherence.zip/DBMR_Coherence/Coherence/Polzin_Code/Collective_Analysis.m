%% Collective analysis of DBMR runs from the paper R. Polzin, I. Klebanov, N. Nüsken
%% and P. Koltai "Nonnegative matrix factorization for coherent set identification by direct low rank maximum likelihood estimation"

%% variables
spectrum_full=[];
Log_full=[];
anzahlen=[];
local_spectrum=[];
local_Log=[];
n_dim=100;

% loop for 1000 runs
for tt=1:1000
    Coherence_ALA_Data_Analyze
    spectrum_x=[];
    Log_x=[];
    anzahlen=[anzahlen length(matrix_history)/n_dim];
    for jj=1:(length(matrix_history)/n_dim)
        K=3; gamma=matrix_history(:,(jj-1)*n_dim+1:jj*n_dim);
        Ncd_gamma=N_cd*gamma';
        lambda=zeros(length(N_cd),K);

        for state_j=1:K
            N_j=sum(Ncd_gamma(:,state_j));
            for state_i=1:N_alphaY
                lambda(state_i,state_j)=Ncd_gamma(state_i,state_j)./N_j;
            end
        end

        LogL=0;

        for k=1:K
            for t=1:length(N_cd)
                for state_i=1:length(N_cd)
                    if lambda(state_i,k)>1e-13
                        LogL=LogL+log(lambda(state_i,k))*N_cd(state_i,t)*gamma(k,t);
                    else
                        LogL=LogL+log(1e-13)*N_cd(state_i,t)*gamma(k,t);
                    end
                end
            end
        end

        LogL

        matrix=diag(q)^-0.5*lambda*gamma*diag(p)^0.5;
        [matrix_U matrix_S matrix_V]=svd(matrix);
        spectrum=diag(matrix_S);

        Frobenius=norm(L_til-matrix,'fro')^2;

        if jj==length(matrix_history)/100
            local_Log=[local_Log LogL];
            local_spectrum=[local_spectrum sum(spectrum(1:3).^2)];
        else
        end

        Log_x=[Log_x LogL];
        spectrum_x=[spectrum_x sum(spectrum(1:3).^2)];

    end

    Log_full=[Log_full Log_x];
    spectrum_full=[spectrum_full spectrum_x];

    % plot of DBMR trajectories
    plot(spectrum_x,Log_x,'-','Color',[0.8 0.8 0.8])
    hold on

end

hold on
% plot of data points in black
plot(spectrum_full,Log_full,'k.','MarkerSize',12)

hold on
% plot of data points in red
plot(local_spectrum,local_Log,'r.','MarkerSize',12)

xlim([0,3])
ylim([-12*10^4,-8*10^4])

xlabel({'$\sum_{i=1}^{3}\sigma_{i}^{2}(\widetilde{\Lambda})$'},'Interpreter','latex','FontSize', 18); 
ylabel('$\hat\ell(\lambda,\Gamma)$','Interpreter','latex','FontSize', 18)

set(gca,'FontSize',18); % Size is 20
