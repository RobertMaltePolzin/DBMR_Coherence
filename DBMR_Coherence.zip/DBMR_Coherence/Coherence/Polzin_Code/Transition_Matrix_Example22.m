%% Example 22 (piecewise expanding interval map) from the paper R. Polzin, I. Klebanov, N. Nüsken
%% and P. Koltai "Nonnegative matrix factorization for coherent set identification by direct low rank maximum likelihood estimation"

% dd is the perturbation parameter in code line 12
% No perturbation: dd=0
% Small perturbation: dd=1
% Large perturbation: dd=4

%close all; 
%clear;

dd=4; % perturbation parameter

l=90; % number boxes  
n=90;
k=90; % number mc points
x = 1/(2*(l*k)^2):1/(l*k):1-1/(2*l*k);

m=90; % number of boxes

M=1000;
y=vec_cc(x,eps); % cocycle for 4 branches

I = ceil(max(m*mod(y,1),1));
J = ceil(max(m*mod(x,1),1));

% Modulo computation
for i=1:length(I)
    
    I(i)=I(i)+randi([-dd dd],1);
    J(i)=J(i)+randi([-dd dd],1);

    if I(i)>90 || I(i)<0
        I(i)=mod(I(i),90);
    else if I(i)==0
            I(i)=90;
        end
    end
        if J(i)>90 || J(i)<0
        J(i)=mod(J(i),90);
        else if J(i)==0
            J(i)=90;
        end
        end   
end

% DBMR input 
I_DBMR=reshape(I,m,k);
J_DBMR=reshape(J,m,k);

N_cd = sparse(I,J,1,m,l);
N_cd=full(N_cd);

P = sparse(I,J,1/k,m,l);
P=full(P);

p=(1/l)*ones(l,1);
diag_p=diag(p);
q=P*p;
diag_q=diag(q)^-1;

% scaled ulam matrix
P_scaled=diag_q*P*diag_p;
[U,S,V]  = svd(P_scaled);

% plot matrices
figure; imagesc(N_cd); colorbar; 
title("Matrix $N$ for perturbation $\epsilon=$" + dd + "",'Interpreter','latex', 'FontSize', 16)

figure; imagesc(P_scaled); colorbar; 
title("Matrix $\tilde{P}$ for perturbation $\epsilon=$" + dd + "",'Interpreter','latex', 'FontSize', 16)

%% kmeans clustering
% N_cluster = 3;                                             
% IDX = kmeans((V(:,2:N_cluster)),N_cluster);
% figure;
% scatter(x(1:n:n^2),vec_T(vec_T(x(1:n:n^2))),30,IDX,'filled');
% scatter([1:n],evec2(:,3),30,IDX,'filled');

% DBMR input data
I_DBMR=reshape(I_DBMR,numel(I_DBMR),1);  
J_DBMR=reshape(J_DBMR,numel(J_DBMR),1); 
 

