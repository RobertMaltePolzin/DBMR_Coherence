%% File to run DBMR s times and save the best log-likelihood and affiliation matrix
%% for a given eps

s=100; % number of runs
gamma=[]; % affiliation matrix
test=0; % variable for the log-likelihood
eps=-1.08*10^5 % eps value

% loop for running DBMR s times
for i=1:s
    Coherence_ALA_Data_Analyze
    Out(1).LogL

    if Out(1).LogL<eps
        gamma=Out(1).gamma;
        test=Out(1).LogL
        Projection
    end

end
