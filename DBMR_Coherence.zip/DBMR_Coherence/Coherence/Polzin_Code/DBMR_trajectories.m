
%% DBMR trajectory data points of Fig. 5 from the paper R. Polzin, I. Klebanov, N. Nüsken
%% and P. Koltai "Nonnegative matrix factorization for coherent set identification by direct low rank maximum likelihood estimation"

%clear all
%clc

FileName   = 'DBMR_trajectories.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);

plot(spectrum_full,Log_full,'k.','MarkerSize',12)

hold on
% plot of data points in red
plot(local_spectrum,local_Log,'r.','MarkerSize',12)

xlim([0,3])
ylim([-12*10^4,-8*10^4])

xlabel({'$\sum_{i=1}^{3}\sigma_{i}^{2}(\widetilde{\Lambda})$'},'Interpreter','latex','FontSize', 18);
ylabel('$\hat\ell(\lambda,\Gamma)$','Interpreter','latex','FontSize', 18)

set(gca,'FontSize',18); % Size is 20
