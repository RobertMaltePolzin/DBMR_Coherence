%% File for running 100 DBMR runs for Collective analysis
%% saved in test_100_runs.mat

LA_S=zeros(5,100);
Log_S=zeros(5,100);

P2=[];
Gamma2=[];
Indices=zeros(3,1);
tt=-10^32;

for pp=1:100
Coherence_ALA_Data_Analyze	
Projection
LA_S(:,pp)=diag(D_S(1:5,1:5));
Log_S(1,pp)=Out(3).LogL;

if Out(3).LogL>tt
    tt=Out(3).LogL;
    % best run
    save("test_100_runs.mat")
end

end

test=[LA_S(3,:); Log_S(1,:)];
figure; hist3(test')


