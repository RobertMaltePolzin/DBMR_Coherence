%% This m-file reproduces the images of Fig. 1-4 in the paper

% Example 21 (three coherent sets)
Transition_Matrix_Example21
disp('Transition_Matrix_Example21')

% Example 22 (piecewise expanding interval map)
Transition_Matrix_Example22
disp('Transition_Matrix_Example22')

% Figure 1 example for the strongly perturbed case
Plot_Fig1
disp('Plot_Fig1')

% Figure 2 example for the strongly perturbed case
Plot_Fig2
disp('Plot_Fig2')

% Images of singular values in Figure 3
Singular_Values_Fig3
disp('Singular_Values_Fig3')

% Images of singular values in Figure 4
Singular_Values_Fig4
disp('Singular_Values_Fig4')

% Histograms in Figure 3
Histograms_Fig3
disp('Histograms_Fig3')

% Histograms in Figure 4
Histograms_Fig4
disp('Histograms_Fig4')
