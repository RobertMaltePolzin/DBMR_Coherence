%% Singular values of Fig. 4 from the paper R. Polzin, I. Klebanov, N. Nüsken
%% and P. Koltai "Nonnegative matrix factorization for coherent set identification by direct low rank maximum likelihood estimation"

%% Example 22 (piecewise expanding interval map)
% Mat-files are in the folder DBMR_Coherence\Coherence\mat_files:
% No perturbation: 2_d0_100.mat
% Small perturbation: 2_d1_100.mat
% Large perturbation: 2_d4_100.mat

%% No perturbation: 2_d0_100.mat %%
%clear all
%clc

FileName   = '2_d0_100.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);  

figure;
kk=5;
plot([1:kk],diag(P_S(1:kk,1:kk),0),'r.','MarkerSize',24);
hold on;
plot([1*ones(100,1);2*ones(100,1);3*ones(100,1)],[LA_S(1,:) LA_S(2,:) LA_S(3,:) ]','bx','MarkerSize',12);

xticks([1 2 3 4 5]);
xlabel({'$k$'},'Interpreter','latex','FontSize', 16);
ylabel({'$\sigma_{k}$'},'Interpreter','latex', 'FontSize', 16);
ylim([0 1]);
xlim([1 5]);

leg2=legend('$\tilde{P}$','$\tilde{P}\tilde{\Pi}$','Interpreter','latex','FontSize', 16);
set(gca,'FontSize',20); % Size is 20

%% Small perturbation: 2_d1_100.mat %%
%clear all
%clc

FileName   = '2_d1_100.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);  

figure;
kk=5;
plot([1:kk],diag(P_S(1:kk,1:kk),0),'r.','MarkerSize',24);
hold on;
plot([1*ones(100,1);2*ones(100,1);3*ones(100,1)],[LA_S(1,:) LA_S(2,:) LA_S(3,:) ]','bx','MarkerSize',12);

xticks([1 2 3 4 5]);
xlabel({'$k$'},'Interpreter','latex','FontSize', 16);
ylabel({'$\sigma_{k}$'},'Interpreter','latex', 'FontSize', 16);
ylim([0 1]);
xlim([1 5]);

leg2=legend('$\tilde{P}$','$\tilde{P}\tilde{\Pi}$','Interpreter','latex','FontSize', 16);
set(gca,'FontSize',20); % Size is 20

%% Large perturbation: 2_d4_100.mat %%
%clear all
%clc

FileName   = '2_d4_100.mat';
FolderName = ['..' filesep 'mat_files']; % DBMR_Coherence\Coherence\mat_files
File       = fullfile(FolderName, FileName);
load(File);  

figure;
kk=5;
plot([1:kk],diag(P_S(1:kk,1:kk),0),'r.','MarkerSize',24);
hold on;
plot([1*ones(100,1);2*ones(100,1);3*ones(100,1)],[LA_S(1,:) LA_S(2,:) LA_S(3,:) ]','bx','MarkerSize',12);

xticks([1 2 3 4 5]);
xlabel({'$k$'},'Interpreter','latex','FontSize', 16);
ylabel({'$\sigma_{k}$'},'Interpreter','latex', 'FontSize', 16);
ylim([0 1]);
xlim([1 5]);

leg2=legend('$\tilde{P}$','$\tilde{P}\tilde{\Pi}$','Interpreter','latex','FontSize', 16);
set(gca,'FontSize',20); % Size is 20