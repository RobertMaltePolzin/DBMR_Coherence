%% KL Bound and Kappa calculation from the paper R. Polzin, 
%% I. Klebanov, N. Nüsken and P. Koltai "Coherent set identification via direct low rank maximum likelihood estimation"

%% Matrices we use:
% N_cd frequency matrix
% P_new Ulam matrix
% P_til rescaled Ulam matrix
% Lambda_tilde rescaled Lambda matrix

Lambda_tilde=Capital_Lambda; % Capital Lambda tilde.
% test6 projection matrix Pi (not scaled)

% size of Q 
[m n]=size(N_cd);

% Q_ij=(1/S)N is joint distribution
Q=N_cd./length(X);

% log(P_ij)
Test=log(P_new); % logarithm of P_new (Ulam matrix)

%%% 0log(0) convention %%%
index=find(Test==-Inf); % save indices where we have -Infinity in the matrix
% Set entries in Test and Q to zero
Test(index)=0;
Q(index)=0;

% p and q vectors (computed via N_cd count matrix)
q=sum(N_cd')/sum(N_cd(:));
p=sum(N_cd)/sum(N_cd(:));

% Squared Frobenius norm (left side of bound)
Frobenius=norm(P_til-Lambda_tilde,'fro')^2;

% P_new Ulam matrix (see in line 12)
% test6 is Capital Pi (not scaled projection Pi)
DBMR=P_new*test6; % DBMR is capital Lamda
Ul_DB=P_new-DBMR; % Difference P-Lambda

%%% Sum over pj times D_KL(p_ij/Lamda_ij) %%%
%%% Double sum over ij for p(j)*P(i,j)*log(P(i,j)/Lambda(i,j)) %%%
sum_D_KL=0;

Test2=log(P_new./DBMR); % log(p_ij/Lamda_ij)

index1=find(P_new==0);
Test2(index1)=0; % 

P_new2=P_new; 
P_new2(index1)=0; % here convention

for j=1:n
    for i=1:m      
     sum_D_KL=sum_D_KL+p(j)*P_new2(i,j)*Test2(i,j);
    end
end

%fprintf('Sum p(j) times D_KL(P/Lambda)')
%sum_D_KL
%%% end sum_D_KL %%%

%%% KL Bound %%%

%%% start Squared Frobenius norm difference %%%
fprintf('Squared Frobenius norm difference')
Frobenius
%%% end Squared Frobenius norm difference %%%

%%%%%%%%%%%%%%%% Kappa calculations %%%%%%%%%%%%%%%%

%%% start Kappa_1 %%%
vec=[]; % saves R(P(:,j)-Lambda(:,j)) when positive

% Loop
for j=1:n
    if norm(Ul_DB(:,j),'inf')>0; % don't divide by zero
    vec=[vec norm(Ul_DB(:,j),1)/norm(Ul_DB(:,j),'inf')*(1/m)];
    end
end

minR=min(vec);
min(q);
minR;
m/2;
fprintf('Kappa_1')
kappa1=(m/2)*min(q)*minR % kappa1
%%% end Kappa_1 %%%

%%% start Kappa_2 %%%

vec2=[]; % saves R_q when positive

matrix2=diag(1./q)*abs(Ul_DB(:,:));
max_q=max(matrix2); % contains maximum of each column of matrix2

% maximal kappa
for j=1:n
   if max_q(j)>0;
    vec2=[vec2 norm(Ul_DB(:,j),1)/max_q(j)];
   end
end  

minRq=min(vec2); 

fprintf('Kappa_1_q')
kappa2=1/2*minRq 
%%% end Kappa_2 %%%

%%% start Kappa_3 %%%

vec3=[]; % saves R(P(:,j)(1-alpha_j) when positive

% calculating alpha (Can alpha be infinity)
matrix3=abs(Ul_DB(:,:))./P_new;
index2=find(isnan(matrix3));
matrix3(index2)=0;
alpha=(2/3)*max(matrix3); % contains maximum of each column of matrix3

% Loop
for j=1:n
    if norm(P_new(:,j),'inf')>0; % don't divide by zero
    vec3=[vec3 norm(P_new(:,j),1)/norm(P_new(:,j),'inf')*(1/m)*(1-alpha(j))];
    end
end

minRalpha=min(vec3);

fprintf('Kappa_2')
kappa3=(m/2)*min(q)*minRalpha

%%% end Kappa_3 %%%

%%% Start Kappa_4 %%%

vec4=[]; % saves R_q(P(:,j))(1-alpha(j)) when positive

matrix4=diag(1./q)*abs(P_new(:,:));
max_q=max(matrix4'); % contains maximum of each column of matrix4^T

% maximal kappa
for j=1:n
    if max_q(j)>0;
    vec4=[vec4 norm(P_new(:,j),1)/max_q(j)*(1-alpha(j))];
    end
end  

minRq_alpha=min(vec4); 

fprintf('Kappa_2_q')
kappa4=1/2*minRq_alpha 

%%% end kappa4 %%%

%% Maximum Kappa
fprintf('Kappa')
kappa=max([kappa1,kappa2,kappa3,kappa4])

%%% 1. Bound %%%

fprintf('KL bound wrt KL divergence')
(1/kappa)*sum_D_KL %%

%%%  KL Bound  %%%
lbound=0;

Test3=log(P_new); % log(p_ij)
index1=find(P_new==0);
Test3(index1)=0;

P_new3=P_new; P_new3(index1)=0; % here convention

%%%

for j=1:n
    for i=1:m      
     lbound=lbound+p(j)*P_new3(i,j)*Test3(i,j);
    end
end

fprintf('KL bound wrt DBMR objective')
(-1/kappa)*(-lbound+Out(3).LogL/length(X)) %% KL bound
% naive bound
fprintf('Naive bound')
2*max(1./q)*sum_D_KL
