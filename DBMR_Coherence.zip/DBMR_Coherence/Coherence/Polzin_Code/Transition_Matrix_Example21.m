%% Example 21 (three coherent sets) from the paper R. Polzin, I. Klebanov, N. Nüsken
%% and P. Koltai "Nonnegative matrix factorization for coherent set identification by direct low rank maximum likelihood estimation"

% dd is the perturbation parameter in code line 12
% No perturbation: dd=0
% Small perturbation: dd=2
% Large perturbation: dd=10

%close all; 
%clear;

dd=10; % perturbation parameter

l=100; % number of boxes  
k=250; % number MC points

x = 1/(2*(l*k)^2):1/(l*k):1-1/(2*l*k);

m=100; % number of categories
I = ceil(max(m*mod(x,1),1)); % input for DBMR (initial time)

a=[1:50];
a1=[1:25 1:25 1:25 26:50];
a2=[1:25 26:50 26:50 26:50];

a11=[26:50 26:50 1:25 1:25 1:25 1:25 1:25 1:25 1:25 1:25];
a22=[1:25 1:25 26:50 26:50 26:50 26:50 26:50 26:50 26:50 26:50];

b=[51:100];

J=[]; % input for DBMR (end time)

for i=1:25
    J=[J a11];
end

for i=1:25
    J=[J a22];
end

for i=1:250
    J=[J b];
end

for i=1:length(I)
    
    I(i)=I(i)+randi([-dd dd],1);
    J(i)=J(i)+randi([-dd dd],1);

    if I(i)>100 || I(i)<0
        I(i)=mod(I(i),100);
    else if I(i)==0
            I(i)=100;
        end
    end
        if J(i)>100 || J(i)<0
        J(i)=mod(J(i),100);
        else if J(i)==0
            J(i)=100;
        end
        end   
end

% count matrix N
N_cd = sparse(I,J,1,m,l);
N_cd=full(N_cd);

% ulam matrix
P = sparse(I,J,1/k,m,l);
P=full(P);
p=(1/l)*ones(l,1);
diag_p=diag(p);
q=P*p;
diag_q=diag(q)^-1; 

% scaled ulam matrix
P_scaled=diag_q^0.5*P*diag_p^0.5; 
[U,S,V]  = svd(P_scaled);

% plot matrices
figure; imagesc(N_cd); colorbar; 
title("Matrix $N$ for perturbation $\epsilon=$" + dd + "",'Interpreter','latex', 'FontSize', 16)

figure; imagesc(P_scaled); colorbar; 
title("Matrix $\tilde{P}$ for perturbation $\epsilon=$" + dd + "",'Interpreter','latex', 'FontSize', 16)

% DBMR input data
I_DBMR=I'; %
J_DBMR=J'; % 

