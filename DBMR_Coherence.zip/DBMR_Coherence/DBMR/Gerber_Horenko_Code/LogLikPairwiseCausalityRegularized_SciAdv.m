function [ y,dy] = LogLikPairwiseCausalityRegularized_SciAdv(x,N_cd,N_alphaX,N_alphaY,T,gamma_norm)

N=reshape(N_cd',N_alphaY*N_alphaX,1)';
y=-sum(log(x).*N);
dy=-N./x;

X=reshape(x,N_alphaX,N_alphaY)';

DY=zeros(N_alphaY,N_alphaX);
for k=1:N_alphaX
    y=y+gamma_norm(k)*X(:,k)'*X(:,k);
    DY(:,k)=2*gamma_norm(k)*X(:,k);
end

dy=dy+reshape(DY',N_alphaY*N_alphaX,1)';

y=y./T;
dy=dy./T;
end

