function [P,fff,IC,LogL_cd,N_par,LLL] = PRP_measure_clustering_H1_v2(T,IC,gamma,K,N_cd_old,P_init)
[N_alphaY,N_alphaX]=size(N_cd_old);
N_alphaX_old=N_alphaX;
% if nargin>7
%     [X,alphaX,N_alphaX] = Gamma2X(gamma,X,K,T);
% end

%%% dringend umprogrammieren!!
N_cd=zeros(N_alphaY,K);
LogL_cd=zeros(K,N_alphaX_old);
LogL_cd_2=zeros(K,N_alphaX_old);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TRY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Aeq=ones(N_alphaY,1)';
% beq=1;
% x0=zeros(N_alphaY,1)';
% size(x0)
% %x0(:)=1/N_alphaY;
% size(P_init')
% lb=zeros(N_alphaY,1)';
% ub=ones(N_alphaY,1)';
% s=N_alphaY;
% 
% P_cd=zeros(N_alphaY,K);
% 
% for hh=1:K
% fun = @(lamda)gamma(hh,:)*((flog((lamda(1:s))))*N_cd_old)';
% x=fmincon(fun,P_init(:,hh)',[],[],Aeq,beq,lb,ub);
% P_cd(:,hh)=x;
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TRY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% erg�nzt (volle Matrix)
%N_cd_old=full(N_cd_old);
%%% Auskommentiert 

%% Schleife �ber i und k f�r lamda_ik
% for k=1:K
%     for state_i=1:N_alphaY
% 
%            %% Schleife �ber sum j (DBMR supplement S.19) 
%         for state_j=1:N_alphaX
%             N_cd(state_i,k)=N_cd(state_i,k)+gamma(k,state_j)*N_cd_old(state_i,state_j);
%         end
%     end
% end

%%% Ab hier auskommentiert
N_cd=N_cd_old*gamma';
% 
% xxx0=reshape(P_init',K*N_alphaY,1)';
% [~,iii]=find(xxx0<1e-12);xxx0(iii)=1e-12;
% 
P_cd=zeros(N_alphaY,K);

for state_j=1:K
    N_j=sum(N_cd(:,state_j));
    for state_i=1:N_alphaY
        P_cd(state_i,state_j)=N_cd(state_i,state_j)./N_j;
    end
end
P=P_cd;

for k=1:K
    for t=1:N_alphaX_old
        
        for state_i=1:N_alphaY %%% Hier Problem
            if P(state_i,k)>1e-13
                LogL_cd(k,t)=LogL_cd(k,t)-log(P(state_i,k))*N_cd_old(state_i,t);
                %LogL_cd(k,t)=LogL_cd(k,t)-log(P(state_i,k))*N_cd_old(state_i,t)+log((1-P(state_i,k)))*N_cd_old(state_i,t);
                
            
            else
                LogL_cd(k,t)=LogL_cd(k,t)-log(1e-13)*N_cd_old(state_i,t);
                %LogL_cd(k,t)=LogL_cd(k,t)-log(1e-13)*N_cd_old(state_i,t)+log((1-1e-13))*N_cd_old(state_i,t);
                
            
            end
        end
    end
end

% Test=log(P);
% Test(Test==-Inf)=log(1e-13);
% LogL_cd_2=-N_cd_old'*Test;
% LogL_cd=LogL_cd_2';


% N_par=0;npp=zeros(1,N_alphaY);
% for state_i=1:N_alphaY
%     pp=sort(P(state_i,:),'descend');
%     npp(state_i)=length(find(abs(diff(pp))>1e-8))+1;
%     N_par=N_par+npp(state_i);
% end
% xxx=reshape(gamma,1,K*N_alphaX_old);
N_par=(N_alphaY-1)*K;%0.5*xxx*H_g*xxx';%N_par-min(npp);
LLL=0;
for t=1:N_alphaX_old
    for k=1:K
    LLL=LLL-gamma(k,t)*LogL_cd(k,t);
    end
end
if strcmp(IC,'BIC'),
    IC=-2*LLL+N_par*(log(T));%+2*N_par_cd;%+2*N_par_cd*(N_par_cd+1)/(T-N_par_cd-1);%-log(2*pi));
else
    IC=-2*LLL+2*N_par+2*N_par*(N_par+1)/(T-N_par-1);%-log(2*pi));
end
%LogL_cd=LogL_cd./T;
fff=-LLL;%/T;


end

