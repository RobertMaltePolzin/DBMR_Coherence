%% Direct Bayesian Model Reduction (DBMR-Algorithm) described
%% in the paper
%% S. Gerber and I. Horenko, "Towards a direct probability-preserving
%% identification of reduced dynamical models for
%% categorical processes", PNAS, 2017
%%
%%
%% This code documents application of the DBMR-Algorithm to a problem of 
%% identification of the reduced model for the categorical time series dynamics of 
%% Ramachandran states from a discretized MD trajectory of torsion
%% angles with a time step tau=100 ps. 
%% 
%% 
%% Analyzed data is loaded from the file 
%% data_10ala_transformed.mat
%% with the matrix variable X (containing Ramachandran states for the eight "interior" peptide junctions
%% at time (t-1) - two freely-rotated "exterior" junctions at the ends of the petide chain are not taken into account
%% since they are more-or-less freely-rotating), vector variable Y (containing Ramachandran states of the peptide junction
%% 1 at time (t)) and the vector variable Z (containing the a priory regularization weights for different junctions,
%% only used in the graph-regularized version of the DBR-Algorithm). Details
%% of the graph-induced regularization procedure for clustering algorithms are described
%% in the paper
%% S. Gerber and I.Horenko "Improving clustering by imposing network information", Science Advances (AAAS), 1(7), e1500163 

clear all
close all
clc

load data_10ala_transformed
% Y=I_DBMR';
% X=J_DBMR';
% Z=zeros(1,length(J));
Z(1,1)=1;
size(X)
size(Y)
%Y
T=size(X,1);
N_train=T;
%figure(100);

if N_train==1
N_train2=T;
else
    N_train2=N_train;
end
[Xf,St_Y]= EmbedCategoricalVect(X(1:N_train2,:)');
Y=Y';%EmbedCategoricalVect(Y');
Yf=Y(1:N_train2);
dim=size(St_Y,2);
[mm,ii]=sort((St_Y(1,:)));
for t=1:length(ii)
    iii=find(Xf==ii(t));
Xff(iii)=t;
end
Xf=Xff;
%%%%%%%%%%
St_Y=St_Y(:,ii);
[alphaX,N_alphaX] = GetCategoriesNames(Xf);
[alphaY,N_alphaY] = GetCategoriesNames(Yf);
KKK=[2:20];
GraphWeights=Z;
opt.eps1=[0];

%% Setting opt.eps1 to some value bigger then zero will execute
%% the graph-regularized version of the procedure 
%% (see Gerber/Horenko, Science Advances, 1(7), 2015).

% Erste Anwendung DBMR
opt.eps2=0;opt.IC='BIC';
[ Outs_stat,ICs_stat,N_pars_stat,LogLs_stat] = DBMR_Algorithm(Xf,Yf,alphaX,...
    N_alphaX,alphaY,N_alphaY,opt.IC,1,0,opt.eps2,St_Y);
IC_stat=-2*LogLs_stat+log(N_alphaX);



for k=1:length(KKK)
    
    k
      fprintf('Hello!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
    opt.K=KKK(k);
    for i=1:length(opt.eps1)
        disp([num2str(opt.K) ' clusters, epsilon = ' num2str(opt.eps1(i))])
    clear Outs ICs N_pars
    [ Outs,ICs,N_pars,LogLs] = DBMR_Algorithm(Xf,Yf,alphaX,N_alphaX,alphaY,N_alphaY,opt.IC,opt.K,opt.eps1(i),opt.eps2,St_Y);
    % Setzen von Gamma
    gamma_train{k,i}= Outs.gamma;
    if N_train2~=T
        [Y_model{k,i},LLL(k,i),gamma_test{k,i}] = AssimilateGammaTest(X(N_train2:T,:),Y(N_train2:T),St_Y,Outs.gamma,Outs.P);
    end 
    [VV,DD]=eig(full(Outs.H_D));
    nn=0;
    for iii=1:opt.K-1
        nn=nn+sum((VV'*gamma_train{k,i}(iii,:)').^2>1e-4);
    end
    N_pars=nn+N_pars ; 
    Out(k,i)=Outs;
    % Information criterion
    IC(k,i)=-2*LogLs+N_pars*log(N_alphaX);
    N_par(k,i)=N_pars; 
    % Log Likelihood
    LogL(k,i)=LogLs;
    end
end

% col='brgkmcybrgkmcybrgkmcybrgkmcybrgkmcybrgkmcy';
% 
% % Nicht reduzierte Version
% [P,LL,IC_AICc,IC_BIC,N_cd]= TransferOperator_ML_Estimate(Xf,alphaX,N_alphaX,Yf,alphaY,N_alphaY);
% 
% [ lambda_nmf,Gamma_nmf, L_nmf] = nnmf_Bayes_constrained_v2(P,2);
% [ lambda_rb,Gamma_rb, L_rb] = reduce_Bayes_constrained_v2(N_cd,2);
% [ lambda_ex,Gamma_ex, L_ex] = reduce_Bayes_constrained_exact(N_cd,2);
% 
% [P,LL,IC_AICc,IC_BIC,N_cd,LL_nmf,IC_AICc_nmf,IC_BIC_nmf]= TransferOperator_ML_Estimate(Xf,alphaX,N_alphaX,Yf,alphaY,N_alphaY,lambda_nmf,Gamma_nmf);
% disp(['Full Max. Log-Likelihood:' num2str(LL) ', Full AICc:',...
%     num2str(IC_AICc) ', Full BIC:' num2str(IC_BIC)]);
% disp(['NNMF Max. Log-Likelihood:' num2str(LL_nmf) ', NNMF AICc:'...
%     num2str(IC_AICc_nmf) ', NNMF BIC:' num2str(IC_BIC_nmf)]);
% 
% N_par=2*sum(abs(sign(diff(Gamma_rb(1,:)))))+1+4;
% IC_BIC_rb=2*L_rb+N_par*(log(T));
% IC_AICc_rb=2*L_rb+2*N_par+2*N_par*(N_par+1)/(T-N_par-1);
% disp(['Reduced NLOPT Max. Log-Likelihood:' num2str(-L_rb) ', Reduced NLOPT AICc:'...
%     num2str(IC_AICc_rb) ', Reduced NLOPT BIC:' num2str(IC_BIC_rb)]);
% 
% N_par=2*sum(abs(sign(diff(Gamma_ex(1,:)))))+1+4;
% IC_BIC_ex=2*L_ex+N_par*(log(T));
% IC_AICc_ex=2*L_ex+2*N_par+2*N_par*(N_par+1)/(T-N_par-1);
% disp(['Reduced exact Max. Log-Likelihood:' num2str(-L_ex) ', Reduced exact AICc:'...
%     num2str(IC_AICc_ex) ', Reduced exact BIC:' num2str(IC_BIC_ex)]);
% 
% N_par=2*sum(abs(sign(diff(Out(1,1).gamma(1,:)))))+1+4;
% IC_BIC_red=-2*LogL(1,1)+N_par*(log(T));
% IC_AICc_red=-2*LogL(1,1)+2*N_par+2*N_par*(N_par+1)/(T-N_par-1);
% disp(['Reduced model Max. Log-Likelihood:' num2str(LogL(1,1)) ',Reduced model AICc:'...
%     num2str(IC_AICc_red) ',Reduced model BIC:' num2str(IC_BIC_red)]);
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Plots%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% k=1;j=1;
% figure;
% for ind=1:KKK(k)
% ii=find(Gamma_nmf(ind,:)>0.8);
% subplot(KKK(k),1,ind);
% % Plot der Causality box
% imagesc(St_Y(:,ii),[1 3]);
% set(gca,'LineWidth',2,'FontSize', 16); 
% title(['K=' num2str(KKK(k)) ', Causality Box ' num2str(ind)],'FontSize', 16);
% xlabel('Index of a Combination X (531 Total Combinations)','FontSize', 12);
% ylabel('Index of a peptide','FontSize', 12);
% end
% 
% % figure;
% % % Gamma Plot
% % plot(Out(1,1).gamma(1,:),'--.');hold on;
% % % staes in red 1/3 
% % plot(St_Y(1,:)/3,'r--');
% % 
% % ylim([0 1.2])
% % % manuell eingestellt
% % text(220,0.7,'Ramachandran State 2')
% % text(50,0.35,'Ramachandran State 1')
% % text(420,1.1,'Ramachandran State 2')
% % set(gca,'LineWidth',2,'FontSize', 16);
% % 
% % figure;
% % for ii=1:KKK(k)
% %     hold on;plot(Out(k,j).gamma(ii,:),[col(ii) '.--']);ylim([-0.1 1.1]);
% % end
% % 
% % Out(k,j).P
% % figure;
% % for ind=1:KKK(k)
% % ii=find(Out(k,j).gamma(ind,:)>0.8);
% % subplot(KKK(k),1,ind);
% % % Plot der Causality box
% % imagesc(St_Y(:,ii),[1 3]);
% % set(gca,'LineWidth',2,'FontSize', 16); 
% % title(['K=' num2str(KKK(k)) ', Causality Box ' num2str(ind)],'FontSize', 16);
% % xlabel('Index of a Combination X (531 Total Combinations)','FontSize', 12);
% % ylabel('Index of a peptide','FontSize', 12);
% % end
% % clear vv
% % for kk=1:size(Out(k,j).gamma,1)
% %     NN=sum(Out(k,j).gamma(kk,:));
% %     %kk=2;
% %     for i=1:size(St_Y,1)
% %         [alphaXst,N_alphaXst] = GetCategoriesNames(St_Y(i,:));
% %         vv{i,kk}=zeros(1,N_alphaXst);
% %         for t=1:dim
% %             for ii=1:N_alphaXst
% %                 if St_Y(i,t)==alphaXst{ii}
% %                     vv{i,kk}(ii)=vv{i,kk}(ii)+(Out(k,j).gamma(kk,t))/NN;
% %                 end
% %             end
% %         end
% %         figure(200);subplot(size(St_Y,1),1,i);hold on;plot(vv{i,kk},[col(kk) '-o'],'LineWidth',2);
% %         ylim([-0.05 1.05]);
% %         set(gca,'LineWidth',2,'FontSize', 16); 
% %     end
% % end
% Out(k,j).P
% %save(['mat_' num2str(ind_Y) '.mat'])
% 

