function [ L,dL] = LogLik_gamma(x,N_cd_old,lambda,K,m)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

L=-sum(N_cd_old.*log(lambda*x'));
dL=zeros(1,K);
s_l=lambda*x';
for i1=1:m
    for k1=1:K
            dL(k1)=dL(k1)- N_cd_old(i1)/(s_l(i1))*lambda(i1,k1);
    end
end

