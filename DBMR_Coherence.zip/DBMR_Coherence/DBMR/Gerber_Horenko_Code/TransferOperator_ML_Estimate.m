function [P,LogL,IC_AICc,IC_BIC,N_cd,LogL_nmf,IC_AICc_nmf,IC_BIC_nmf]= TransferOperator_ML_Estimate(X,alphaX,N_alphaX,Y,alphaY,N_alphaY,lambda_nmf,Gamma_nmf)
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here
T=length(X);
N_cd=zeros(N_alphaY,N_alphaX);P=N_cd;
for state_i=1:N_alphaY
    for state_j=1:N_alphaX
        N_cd(state_i,state_j)=sum((Y==alphaY{state_i}).*(X==alphaX{state_j}));
    end
end

for state_j=1:N_alphaX
    P(:,state_j)=N_cd(:,state_j)/sum(N_cd(:,state_j));
end
LogL=0;
for state_i=1:N_alphaY
    for state_j=1:N_alphaX
        if P(state_i,state_j)>1e-12
            LogL=LogL+N_cd(state_i,state_j)*log(P(state_i,state_j));
        end
    end
end
N_par=N_alphaX*(N_alphaY-1);
%%% Compute the Akaike and the Bayesian Information Criterion
IC_BIC=-2*LogL+N_par*(log(T));%+2*N_par_cd;%+2*N_par_cd*(N_par_cd+1)/(T-N_par_cd-1);%-log(2*pi));
IC_AICc=-2*LogL+2*N_par+2*N_par*(N_par+1)/(T-N_par-1);%-log(2*pi));

if nargin>6
    P_nmf=lambda_nmf*Gamma_nmf;
    LogL_nmf=0;
    for state_i=1:N_alphaY
        for state_j=1:N_alphaX
            if P_nmf(state_i,state_j)>1e-12
                LogL_nmf=LogL_nmf+N_cd(state_i,state_j)*log(P_nmf(state_i,state_j));
            end
        end
    end
IC_BIC_nmf=-2*LogL_nmf+N_par*(log(T));%+2*N_par_cd;%+2*N_par_cd*(N_par_cd+1)/(T-N_par_cd-1);%-log(2*pi));
IC_AICc_nmf=-2*LogL_nmf+2*N_par+2*N_par*(N_par+1)/(T-N_par-1);%-log(2*pi));
end


end
