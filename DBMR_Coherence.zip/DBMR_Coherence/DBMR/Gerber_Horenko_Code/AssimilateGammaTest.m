function [Y_model,LLL,gamma_test] = AssimilateGammaTest(X_test,Y_test,St_Y,gamma,P)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

[T]=size(X_test,1);
[K,N_st]=size(gamma);
options=optimset('MaxIter',100,'Display','off','Algorithm','interior-point-convex');
Aeq=ones(1,K);beq=1;A=-eye(K);b=zeros(K,1);
N_Y=size(P,1);
gamma_test=zeros(K,T);
Y_model=zeros(N_Y,T);LLL=0;
for t=1:T
    D=zeros(1,N_st);%dd=D;
    for j=1:N_st
        D(j)=KernelDistance(X_test(t,:)',St_Y(:,j));%exp(-sum((X_test(t,:)'-St_Y(:,j)).^2));
        %dd(j)=sum((X_test(t,:)'-St_Y(:,j)).^2);
    end
    f=zeros(1,K);
    for k=1:K
        f(k)=-2*sum(gamma(k,:).*D);
    end
    H=2*sum(D)*eye(K);    
    [gamma_test(:,t),f,flag,output] =  quadprog(H,f,A,b,Aeq,beq,[],[],[],options);
   for k=1:K
       Y_model(:,t)=Y_model(:,t)+gamma_test(k,t)*P(:,k);
   end
   LLL=LLL+log(Y_model(Y_test(t),t));
end

