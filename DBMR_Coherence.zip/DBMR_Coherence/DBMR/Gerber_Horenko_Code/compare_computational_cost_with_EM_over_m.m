%% Computational comparison of PLSA-EM and DBRM
%% Creates Figure 1 from the paper
%% S. Gerber, I. Horenko "Towards a direct and scalable identification of 
%% reduced models for categorical processes", PNAS, 2017

clear all
close all
clc
rand('seed',1);randn('seed',1);
M=[2:10 15];n=10;K=2;
N=[300 400 600 800 1200 2400 4000 4800 6500 10000];%round(n.^[1:0.2:4]);
N_anneal=1000;

in.T=10000;
in.IC='BIC';
in.K=K;
in.eps1=0;
in.eps2=0;
in.A=[];
in.b=[];
in.Aeq=[];
in.beq=[];
in.P_init=[];
in.MaxIter=500;
tol=1e-6;
for k_m=1:length(M)
    m=M(k_m);
    m
    for i=1:length(N)
        i
        in.N_alphaX=N(i);
        in.tol=1e-6*in.N_alphaX*m;
        
        
        for k=1:N_anneal
            %k
            clear N_cd P
            N_cd=round(10*rand(m,N(i)));P=0*N_cd;
            in.N_cd_old=N_cd;
            for j=1:N(i)
                s=sum(N_cd(:,j));
                if s>0
                    P(:,j)=N_cd(:,j)./(s);
                end
            end
            in.gamma_init=zeros(in.K,in.N_alphaX);
            for t=1:in.N_alphaX
                rr=ceil(in.K*rand(1));
                in.gamma_init(rr,t)=1;
            end
            in.P_init=rand(m,in.K);in.P_init=in.P_init./(ones(m,m)*in.P_init);
            for t=1:in.K
                rr=ceil(in.K*rand(1));
                in.gamma_init(rr,t)=1;
            end
            in.H_g=zeros(in.K*in.N_alphaX);
            in.tol=in.N_alphaX*m*tol;
            %tic;%[IDX,C]=kmeans(P',K);
            [out]=AdaptiveBoxDiscretization_H1_v2(in);
            %t_dbmr2(i,k)=toc;
            t_dbmr1(i,k)=out.tt(1);%t_edbmr2(i,k)=out.tt(2);
            N_iter_dbrm(i,k)=length(out.acf);
            LogL_dbrm(i,k)=out.LogL;
            %tic;%[IDX,C]=kmeans(P',K);
            %%%[out]=AdaptiveBoxDiscretization_H1_EDBRM(in);
            %t_edbmr2(i,k)=toc;
            %%%t_edbmr1(i,k)=out.tt(1);%t_edbmr2(i,k)=out.tt(2);
            N_iter_edbrm(i,k)=length(out.acf);
            %pid=pwd;
            %cd /Users/horenkoi/Downloads/PLSA_TEM_EM/PLSA_TEM_EM
            tic;[prob_term_topic, prob_topic_doc,lls] = plsa(N_cd, in.K, in.tol);
            t_em(i,k)=toc;
            LogL_em(i,k)=lls(length(lls));
            N_iter_em(i,k)=length(lls);
            %cd(pid);
            
            if and(i==1,k==3)
                t_dbmr1(1,1:2)=t_dbmr1(1,3);
                %t_dbmr2(1,1:2)=t_dbmr2(1,3);
                %%%t_edbmr1(1,1:2)=t_edbmr1(1,3);
                t_em(1,1:2)=t_em(1,3);
                %t_edbmr2(1,1:2)=t_edbmr2(1,3);
            end
            
        end
    end
    rel_err(k_m,:)=mean(((LogL_dbrm-LogL_em)./(LogL_em))');
    log_dbrm(k_m,:,:)=LogL_dbrm;
    log_em(k_m,:,:)=LogL_em;

    N_dbrm_m(k_m,:)=mean(N_iter_dbrm(1:i,:)');
    N_em_m(k_m,:)=mean(N_iter_em(1:i,:)');
    t_dbmr2=t_dbmr1.*N_iter_dbrm;
    t_dbrm_m(k_m,:)=mean(t_dbmr2(1:i,:)');
    t_em_m(k_m,:)=mean(t_em(1:i,:)');    
end
m=10;
[MM,NN]=meshgrid(M(1:m),N);
figure;surf(NN,MM,N_dbrm_m(1:m,:)');hold on;
surf(NN,MM,N_em_m(1:m,:)');shading interp
figure;surf(NN,MM,t_dbrm_m(1:m,:)');hold on;
surf(NN,MM,t_em_m(1:m,:)')
figure;surf(NN,MM,rel_err(1:m,:)');
%%t_edbmr2=t_edbmr1.*N_iter_edbrm;
%figure;semilogy(N(1:i),mean(t_dbmr(1:i,:)'),'b+');hold on;semilogy(N(1:i),mean(t_edbmr(1:i,:)'),'m*');
