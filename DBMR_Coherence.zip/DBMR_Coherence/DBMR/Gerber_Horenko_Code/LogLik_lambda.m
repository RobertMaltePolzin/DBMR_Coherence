function [ L,dL] = LogLik_lambda(x,N_cd_old,gamma,K,m,n)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
lambda=reshape(x,m,K);

L=-sum(sum(N_cd_old.*log(lambda*gamma)));
%A=times(N_cd_old,log(lambda*gamma));
%L=-sum(A,'all');


dL=zeros(m,K);
%dL2=zeros(m,K);
s_l=lambda*gamma;

for i1=1:m
    for k1=1:K
        for j=1:n
            dL(i1,k1)=dL(i1,k1)- N_cd_old(i1,j)/(s_l(i1,j))*gamma(k1,j);
        end
    end
end

%dL
%dL=-(N_cd_old./s_l)*gamma';


dL=reshape(dL,1,m*K);
