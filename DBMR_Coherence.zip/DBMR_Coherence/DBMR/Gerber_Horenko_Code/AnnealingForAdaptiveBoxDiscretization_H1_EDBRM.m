function [ AnnealOut] = AnnealingForAdaptiveBoxDiscretization_H1_EDBRM(in)


for i=1:in.N_anneal
    in_anneal{i}=in;
    if i>1
        in_anneal{i}.gamma_init=zeros(in.K,in.N_alphaX);
            for t=1:in.N_alphaX
                rr=ceil(in.K*rand(1));
                in_anneal{i}.gamma_init(rr,t)=1;
            end
    end
end
for i=1:in.N_anneal
   [ out{i}] = AdaptiveBoxDiscretization_H1_EDBRM(in_anneal{i}); 
end
IC_all=zeros(1,in.N_anneal);
for i=1:in.N_anneal
    IC_all(i)=out{i}.LogL;
end
[AnnealOut.IC,ii]=min(IC_all);
AnnealOut.gamma=out{ii}.gamma;
AnnealOut.P=out{ii}.P;
AnnealOut.acf=out{ii}.acf;
AnnealOut.N_par=out{ii}.N_par;
AnnealOut.LogL=out{ii}.LogL;
