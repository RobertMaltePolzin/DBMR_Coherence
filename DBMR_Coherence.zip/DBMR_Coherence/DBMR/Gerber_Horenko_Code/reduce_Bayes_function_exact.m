function [y,dy] = reduce_Bayes_function_exact(x0,A,n,m,K)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
lambda=reshape(x0(1:m*K),m,K);
Gamma=reshape(x0(1+m*K:m*K+K*n),K,n);
y=-sum(sum(A.*(log(lambda*Gamma)))); %%%%%%%%%%%%%%%%%%%%%%%%%%
dl_dlambda=lambda*0;
dl_dGamma=Gamma*0;
for i=1:m
    for j=1:n
        for k=1:K
            sk=0;
            for k1=1:K
                sk=sk+lambda(i,k1)*Gamma(k1,j);
            end
            dl_dlambda(i,k)=dl_dlambda(i,k)+A(i,j)*Gamma(k,j)/sk;
            dl_dGamma(k,j)=dl_dGamma(k,j)+A(i,j)*lambda(i,k)/sk;   
        end
    end
end
dy=-[reshape(dl_dlambda,1,m*K) reshape(dl_dGamma,1,n*K)];
end

