function [prob_term_topic, prob_topic_doc,lls] = plsa(termDocMatrix, numTopic, epsilon)

% Fit a plsa model from a given term-document matrix with ordinal EM
% algortihm
% This code was inspired by the following code (https://github.com/lizhangzhan/plsa)
% AUTHOR: Ikko Kimura, Osaka University, 2016/04/02
% USAGE: [prob_term_topic, prob_topic_doc,lls] = plsa(termDocMatrix, numTopic, epsilon)
% epsilon: criteria for stoppping EM algorithm (default: 1e-5)
% As for pLSA please refer to the following paper
% Thomas Hofmann, 2001, Machine Learning, 42, 177-196, Unsupervised Learning by
% Probabilistic Latent Semantic Analysis
%
% Debugged by I. Horenko in Jan 2017 (there was a problem with NaNs when some of the frequency
% matrix elements where zero) 

if nargin < 3
    epsilon=1e-5;
end

[numTerm, numDoc] = size(termDocMatrix);

%%%%%%%%%%%%%%%%%%%%%%%%%%
% !!! INITIALIZATIONS !!!
%%%%%%%%%%%%%%%%%%%%%%%%%%
prob_term_topic = rand(numTerm, numTopic); % p(term | topic)
prob_term_topic = bsxfun(@rdivide,prob_term_topic,sum(prob_term_topic));

prob_topic_doc = rand(numTopic, numDoc);   % p(doc | topic)
prob_topic_doc = bsxfun(@rdivide,prob_topic_doc,sum(prob_topic_doc));

prob_topic_term_doc=zeros(numTerm, numDoc,numTopic);

prob_term_doc=prob_term_topic * prob_topic_doc;

[ii,jj,mm]=find(termDocMatrix>0);
lls=0;
for ttt=1:length(ii)
    lls=lls+termDocMatrix(ii(ttt),jj(ttt))* log(prob_term_doc(ii(ttt),jj(ttt)));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% !!! ITERATION STARTS !!!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
i=1;
done=0;
while and(~done,i<10000); i = i+ 1; 
	%%% E-step...
    [prob_topic_term_doc]=Estep(prob_topic_doc,prob_term_topic,prob_term_doc,prob_topic_term_doc);
    %%% M-step...
    [prob_topic_doc,prob_term_topic]=Mstep(termDocMatrix,prob_topic_term_doc);
    
    %%% calculate likelihood and update p(term, doc) 
    prob_term_doc  = prob_term_topic*prob_topic_doc;
    ll=0;
    for ttt=1:length(ii)
        ll=ll+termDocMatrix(ii(ttt),jj(ttt))* log(prob_term_doc(ii(ttt),jj(ttt)));
    end
	
    %display(sprintf('Iteration %d Loglikelihood %d',i,ll));
    lls= [lls;ll];
    
    rel_ch = (lls(i) - lls(i-1));%/abs(lls(i-1)); 
    if rel_ch< epsilon && i> 5 
        done=1;
        %display(sprintf('Convergence was made after %d steps..',i))
    end
end

end

function [prob_topic_term_doc]=Estep(prob_topic_doc,prob_term_topic,prob_term_doc,prob_topic_term_doc)
%perform E step
for z = 1:size(prob_topic_term_doc,3) %% Hmm...
prob_topic_term_doc(:, :, z) = bsxfun(@times,prob_topic_doc(z,:),prob_term_topic(:,z))./(prob_term_doc+eps);
end
%prob_topic_term_doc(isnan(prob_topic_term_doc))=0;
end

function [prob_topic_doc,prob_term_topic]=Mstep(termDocMatrix,prob_topic_term_doc)
% perform M step
g=bsxfun(@times,termDocMatrix,prob_topic_term_doc);
prob_topic_doc=permute(sum(g,1),[3 2 1]);
prob_term_topic=permute(sum(g,2),[1 3 2]);
% Normalize the data
ss=sum(prob_topic_doc);
[~,ii]=find(ss>0);
prob_topic_doc(:,ii) = bsxfun(@rdivide,prob_topic_doc(:,ii),ss(ii));
prob_term_topic = bsxfun(@rdivide,prob_term_topic,sum(prob_term_topic));
end