function [ out ] = AdaptiveBoxDiscretization_H1_v2(in,matrix1)

T=in.T;
N_alphaX=in.N_alphaX;
IC=in.IC;
K=in.K;
gamma=in.gamma_init;
hello=gamma;

%%% Beides sehr wichtig für Kontrolle
%figure; imagesc(gamma')
%sum(gamma')


%figure; imagesc(gamma)
%in.eps1=0;
eps1=in.eps1;
eps2=in.eps2;
i=1;
DeltaL=1e8;
options=optimset('MaxIter',1000,'Display','off','Algorithm','interior-point-convex');

matrix_history=[];

while and(i<in.MaxIter,abs(DeltaL)>in.tol)
    %% Hier sieht man gamma in der Schleife 
    gamma_old=gamma;
    %figure; imagesc(gamma)
%figure; 
matrix_history=[matrix_history gamma];
%imagesc(matrix_history)
save('history','matrix_history')
    % Graph based version
    if abs(in.eps1)>1e-12
        
        [P,fff,IC,LogL_cd,N_par,LLL] = PRP_measure_clustering_H1_v2_SciAdv(T,IC,gamma,K,eps1,eps2,in.N_cd_old,in.A,in.b,in.Aeq,in.beq,in.P_init,in.H_g);
        in.P_init=P;
        f=reshape(LogL_cd,1,K*N_alphaX);
        xxx0=reshape(gamma,1,K*N_alphaX);
        norm_P=zeros(1,K);
        for kk=1:K
            norm_P(kk)=P(:,kk)'*P(:,kk);
        end
        N_X=N_alphaX;
        H=zeros(N_X*K);
        for ii=1:N_X
            for kk=1:K
                for jj=1:N_X
                    H(kk+(ii-1)*K,kk+(jj-1)*K)=norm_P(kk)*in.H_g(kk+(ii-1)*K,kk+(jj-1)*K);
                end
            end
        end
        f0=f*xxx0'+0.5*in.eps1*xxx0*H*xxx0';
        [xxx,acf(i),flag,output] =  quadprog(in.eps1*sparse(H),f,(in.A_g),in.b_g,(in.Aeq_g),(in.beq_g),[],[],xxx0,options);
        
    else
        tic; 
        [P,fff,IC,LogL_cd,N_par,LLL] = PRP_measure_clustering_H1_v2(T,IC,gamma,K,in.N_cd_old,in.P_init);
        
        %time(i)=toc;
        in.P_init=P; % initiales P wird gesetzt!
        %figure; imagesc(P)
        f=reshape(LogL_cd,1,K*N_alphaX);
        xxx0=reshape(gamma,1,K*N_alphaX);
        f0=f*xxx0';
        %[xxx,acf(i)] =  linprog(f,in.A_g,in.b_g,in.Aeq_g,in.beq_g,[],[],xxx0,options);
        %f2=reshape(f',N_alphaX,K)';
        f2=reshape(f,K,N_alphaX);
        if K>1
            [kk,ii]=min(f2); %%% hier wird das Minimum gesucht von f2
        else
            ii=ones(1,N_alphaX);
        end
        val=0*reshape(f,N_alphaX,K)';
        for ind=1:N_alphaX,
            val(ii(ind),ind)=1;       
        end
        %val
        xxx=reshape(val,1,K*N_alphaX);
        %figure; imagesc(xxx)
        acf(i)=f*xxx';
        tt(i)=toc;
        %f0
    end
    if f0>=acf(i)
        gamma=reshape(xxx,K,N_alphaX); % hier wird gamma gesetzt
        %figure; imagesc(gamma)
    %elseif i>1
    %    gamma=gamma_old;
    %    acf(i)=acf(i-1);
    end
%     for t=1:N_alphaX
%        [~,ii]=min(LogL_cd(:,t));   
%        gamma(t)=ii(1);
%     end
    if i>1
        DeltaL=acf(i-1)-acf(i);
    end
    i=i+1;
    %if DeltaL<-1e-7
    %    keyboard
    %end
end
%sum(hello')
out.gamma=gamma;
out.tt=mean(tt);
out.P=P;
out.IC=IC;
out.acf=acf;
out.N_par=N_par;
out.LogL=LLL;
%out.time=mean(time);